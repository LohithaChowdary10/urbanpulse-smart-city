# URBANPULSE — Smart City Traffic Intelligence

A polished, responsive capstone demonstration dashboard based on the uploaded PPT:
**Big Data Analysis of Smart City Traffic Logs Using HDFS, Hadoop Streaming and Hive.**

## Step 1 — Download and extract
1. Download `urbanpulse_smart_city_dashboard.zip`.
2. Right-click the ZIP file → **Extract All**.
3. Open the extracted `enterprise-hr-analytics` folder.

## Step 2 — Open in VS Code
1. Open Visual Studio Code.
2. Select **File → Open Folder**.
3. Choose the extracted `enterprise-hr-analytics` folder.
4. Open `index.html`.

## Step 3 — Run the project
In VS Code, open **Terminal → New Terminal**, then run:

```bash
python -m http.server 5500
```

If `python` is not recognised on Windows, try:

```bash
py -m http.server 5500
```

## Step 4 — View the dashboard
Open your browser and visit:

http://localhost:5500

To stop the local server, return to the terminal and press `Ctrl + C`.

## Demo walkthrough for faculty
1. **Overview:** introduce the KPI cards, traffic volume chart, congestion by road and city hotspot map.
2. **Traffic Monitor:** show the sample traffic event stream.
3. **Data Processing:** click **Execute MapReduce job** and explain the Mapper → Shuffle & Sort → Reducer flow.
4. **Hive Analytics:** select one of the sample queries and click **Execute HiveQL**.
5. **Dataset Lab:** upload a CSV with columns `timestamp,road,vehicle_type,speed`.
6. **Project Modules:** explain the four modules from the PPT.
7. **About Project:** present the technology stack and future scope.

## Important implementation note
This is a front-end capstone demonstration. The dashboard includes an interactive local CSV reader, visual analytics, a simulated Hadoop Streaming pipeline and a simulated Hive query workbench. It does **not** connect to a real Hadoop/HDFS cluster or Apache Hive service. Do not describe the simulated components as a deployed distributed backend. A real deployment requires Hadoop, HDFS, Python streaming scripts, Hive, and a configured dataset/cluster.

## Files
- `index.html` — complete dashboard (HTML, CSS and JavaScript; no npm install required)
- `README.md` — setup and demonstration guide
